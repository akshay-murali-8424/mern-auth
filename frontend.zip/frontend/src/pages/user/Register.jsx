import React from 'react'
import UserRegister from '../../components/userRegister/UserRegister'

function Register() {
  return (
    <UserRegister/>
  )
}

export default Register